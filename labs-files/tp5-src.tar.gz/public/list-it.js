(function () {
  var listContainer = document.querySelector('.list-container');

  getGIFs();

  function getGIFs() {
    fetch('/gif')
      .then(function (response) {
        return response.json();
      })
      .then(function (body) {
        var gifList = body.results;

        if (!gifList) {
          console.warn('No results given.');
          return;
        }

        if (gifList.length > 9) {
          console.error('You shouldn\'t have more than 9 GIFs in your database, please remove some.');
          gifList = gifList.slice(8);
        }


        gifList.forEach(function (gif) {
          var gifContainer = document.createElement('div');
          var deleteGIFBtn = document.createElement('button');
          var titleGIF = document.createElement('span');
          var gifElement = document.createElement('img');

          deleteGIFBtn.classList.add('delete-gif');
          deleteGIFBtn.classList.add('pi-button');
          deleteGIFBtn.addEventListener('click', function () {
            fetch('/gif/' + gif._id, { method: 'DELETE' })
              .then(function (response) {
                if (response.ok) {
                  var gifTitles = document.getElementsByClassName('title-gif');

                  for (var i = 0; i < gifTitles.length; i++) {
                    if (gifTitles[i].textContent === gif.name) {
                      listContainer.removeChild(gifTitles[i].parentElement);
                    }
                  }
                }
              })
              .catch(console.error);
          });

          deleteGIFBtn.textContent = 'Delete GIF';

          titleGIF.classList.add('title-gif');
          titleGIF.textContent = gif.name;

          gifElement.classList.add('gif-img');
          gifElement.setAttribute('src', gif.url);

          gifContainer.classList.add('gif-container');

          gifContainer.appendChild(titleGIF);
          gifContainer.appendChild(deleteGIFBtn);
          gifContainer.appendChild(gifElement);

          listContainer.appendChild(gifContainer);
        });
      });
  }
})();
