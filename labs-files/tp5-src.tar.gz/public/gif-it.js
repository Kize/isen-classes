(function () {
  var gifPreview = document.querySelector('.preview');
  // var cataasURL = 'https://cataas.com/cat/gif';
  // gifPreview.setAttribute('style', `background-image: url('${cataasURL}')`);

  var randomBtn = document.querySelector('.random-gif');
  randomBtn.addEventListener('click', getARandomGIF);

  function getARandomGIF() {
    fetch('/random/gif').then(function (response) {
      return response.json();
    }).then(function (data) {
      document.getElementById('url-input').value = data.url;

      showGIF(data.url);
    }).catch(console.error);
  }

  var showGIFBtn = document.querySelector('.show-gif');
  showGIFBtn.addEventListener('click', function () {
    var url = document.querySelector('#url-input').value;

    if (!url || url.length === 0) {
      window.alert('I need a valid URL to show a gif.');
      return;
    }

    showGIF(url);
  });

  function showGIF(url) {
    gifPreview.setAttribute('src', url);
  }


  var saveGIFBtn = document.querySelector('.save-gif');
  saveGIFBtn.addEventListener('click', saveGIF);

  function saveGIF() {
    var body = {};

    var nameInput = document.querySelector('#name-input');
    var urlInput = document.querySelector('#url-input');

    body.name = nameInput.value;
    body.url = urlInput.value;

    if (!body.name || body.name.length === 0) {
      window.alert('The name must be filled.');
      return;
    }

    if (!body.url || body.url.length === 0) {
      window.alert('The url must be filled.');
      return;
    }

    fetch('/gif', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (body) {
        var formElement = document.querySelector('form');
        var loggerElement = document.createElement('p');

        loggerElement.textContent = 'GIF saved in database with the id : ' + body.id;
        loggerElement.classList.add('logger');

        nameInput.value = '';
        urlInput.value = '';

        formElement.appendChild(loggerElement);
        setTimeout(function () {
          formElement.removeChild(loggerElement);
        }, 2500);
      })
      .catch(console.error);
  }

})();
